
<?php
require("../inc/bd.php"); 
require("../inc/site_config.php"); 
session_start();
$sid = $_SESSION['hash'];
// проверка на админа
$admin_check = "SELECT * FROM kot_user WHERE hash = '$sid'";
$result_admin = mysql_query($admin_check);
$row = mysql_fetch_array($result_admin);
if($row)
{	
    $img = $row['img'];
    $vk_name = $row['vk_name'];
    
$last_check = $row['admin'];
}
if($last_check==1){
$status='Администратор';
}
if($last_check==0){
$status='Игрок';
}
if($last_check==2){
$status='Модератор';
}
if($last_check == 1) {
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" 
href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    
    <link rel="stylesheet" href="../css/5style.css">
   
    <!-- Темная тема 
     <link rel="stylesheet" href=" https://www.bootstrapdash.com/demo/purple/jquery/template/assets/css/demo_2/style.css">
     ------>
     <!-- CВетлая тема -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!--  -------------->
    
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
          <a class="navbar-brand brand-logo-mini" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
           <script>
           
           
             function offliner() {

  $('#mybalance').load('/inc/main.php #mybalance');
		}
		
		setInterval('offliner()',3000);   
                             
                              </script>
          
         
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="<?=$img;?>" alt="image">
                  <span class="availability-status online"></span>
                </div>
                
              </a>
             
            </li>
            
            
            <li class="nav-item dropdown">
             <div>
                 <span id="mybalance"><?=$balance;?></span><i class="mdi mdi-coin"></i>
               
              </div>
            </li>
          
       
          
          
            
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="<?=$img;?>" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?=$vk_name;?></span>
                  <span class="text-secondary text-small"><?=$status;?></span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/';" >
                <span class="menu-title">Главная страница сайта</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
          
            <li class="nav-item active">
                
              <a class="nav-link "  href = "/admin/index.php">
                <span class="menu-title">Настройки</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a onclick="location.href = '/admin/users';"  class="nav-link ">
                <span class="menu-title">Пользователи</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/promo';" >
                <span class="menu-title">Промокоды</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/deps';" >
                <span class="menu-title">Пополнения</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/withdraws';" >
                <span class="menu-title">Выплаты</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/stat';" >
                <span class="menu-title">Статистика сайта</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/percent';" >
                <span class="menu-title">Шансы</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
            
              </span>
            </li>
          </ul>
        </nav>
      
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
<div class="row" id="refs" >
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Настройки 
                   <button id='saved' class="btn btn-gradient-primary" onclick="saves()">Сохранить</button>
                  </h4>
                     <script>
    function saves() {
 $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			   $('#saved').html('Сохранение..');
										},	
                                                                                data: {
         type: "save_edit",
         sitename: $("#sitename").val(),
         sitedomen: $("#sitedomen").val(),
         sitegroup: $("#sitegroup").val(),
         sitesupport: $("#sitesupport").val(),                                    
         sitesecret: $("#sitesecret").val(),
         minbonus: $("#minbonus").val(),
         maxbonus: $("#maxbonus").val(),                                                            
         minwithdraw: $("#minwithdraw").val(),                                         
         bonusreg: $("#bonusreg").val(),  
         fkid: $("#fkid").val(),                                                                                                                        fksecret1: $("#fksecret1").val(),
         fksecret2: $("#fksecret2").val(),
         //new
         depwithdraw: $("#depwithdraw").val(),   
                                                                                  
         minbet: $("#minbet").val(),     
                                                                                  
         maxbet: $("#maxbet").val(), 
                                                                                  
         minper: $("#minper").val(), 
                                                                                  maxper: $("#maxper").val(),
                                                                                  
         fakeonline: $("#fakeonline").val(),
                                                                                  
         fakeinterval: $("#fakeinterval").val(),
                                                                                  
         mindep: $("#mindep").val(),
         token: $("#token").val(),
         idgroup: $("#idgroup").val()  
                                                                                                                            },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {

                //$("#succes_edit").show();                               
				$("#saved").html("Сохранить");
                     //$("#setting-tbl").load("index.php #setting-tbl");
                                            
                                                              
                                            }else{
                //$("#error_edit").show();                               
				//$("#error_edit").html(obj.error);
                                            }
                                        }   
   });
}
    </script>
                         <center>
   <div class="row" id="setting-tbl" style="margin-right:2%;margin-left:2%;width:100%;">
                                                        <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Название сайта</label>
                                                            <input type="text" class="form-control" id="sitename" placeholder="Название сайта" value="<?=$sitename?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Домен сайта</label>
                                                            <input type="text" class="form-control" id="sitedomen" placeholder="Домен сайта" value="<?=$sitedomen?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Ссылка на группу VK</label>
                                                            <input type="text" class="form-control" id="sitegroup" placeholder="Ссылка на группу VK" value="<?=$group?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Ссылка на сообщения VK</label>
                                                            <input type="text" class="form-control" id="sitesupport" placeholder="Ссылка на сообщения VK" value="<?=$site_support?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Секретный ключ сайта</label>
                                                            <input type="text" class="form-control" id="sitesecret" placeholder="Ключ сайта" value="<?=$sitekey?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Мин. бонус в раздаче</label>
                                                            <input type="text" class="form-control" id="minbonus" placeholder="Мин бонус" value="<?=$min_bonus_s?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Макс. бонус в раздаче</label>
                                                            <input type="text" class="form-control" id="maxbonus" placeholder="Макс бонус" value="<?=$max_bonus_s?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Мин. сумма вывода</label>
                                                            <input type="text" class="form-control" id="minwithdraw" placeholder="Мин вывод" value="<?=$min_withdraw_sum?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Депозит для вывода</label>
                                                            <input type="text" class="form-control" id="depwithdraw" placeholder="Депозит для вывода" value="<?=$dep_withdraw?>"/>
                                                          </div>
                                                        </div>
                      
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Мин. сумма ставки</label>
                                                            <input type="text" class="form-control" id="minbet" placeholder="Мин ставка" value="<?=$min_bet?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Макс. сумма ставки</label>
                                                            <input type="text" class="form-control" id="maxbet" placeholder="Макс ставка" value="<?=$max_bet?>"/>
                                                          </div>
                                                        </div>
                                                         <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Мин. шанс выигрыша</label>
                                                            <input type="text" class="form-control" id="minper" placeholder="Мин шанс" value="<?=$min_per?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Макс. шанс выигрыша</label>
                                                            <input type="text" class="form-control" id="maxper" placeholder="Макс шанс" value="<?=$max_per?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Бонус за регистрацию</label>
                                                            <input type="text" class="form-control" id="bonusreg" placeholder="Бонус за регистрацию" value="<?=$bonus_reg?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Прибавить к онлайну</label>
                                                            <input type="text" class="form-control" id="fakeonline" placeholder="Фейк онлайн" value="<?=$fake_online?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Частота ставок ботов (1к = 1сек)</label>
                                                            <input type="text" class="form-control" id="fakeinterval" placeholder="1" value="<?=$fake_interval?>"/>
                                                          </div>
                                                        </div>
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>ID группы VK</label>
                                                            <input type="text" class="form-control" id="idgroup" placeholder="12345" value="<?=$idvk?>"/>
                                                          </div>
                                                        </div>   
                      <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Токен группы VK</label>
                                                            <input type="text" class="form-control" id="token" placeholder="gvuegvue76784bkdd" value="<?=$tokenvk?>"/>
                                                          </div>
                                                        </div>                                   
                      <div class="form-group">
                      <div class="col-lg-12" style="">
                                                            <label>Мин. сумма пополнения</label>
                                                            <input type="text" class="form-control" id="mindep" placeholder="1" value="<?=$min_sum_dep?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>ID FK</label>
                                                            <input type="text" class="form-control" id="fkid" placeholder="ID мерчанта FK" value="<?=$fk_id?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Секрет 1 FK</label>
                                                            <input type="text" class="form-control" id="fksecret1" placeholder="Секрет 1 FK" value="<?=$fk_secret_1?>"/>
                                                          </div>
                                                        </div>
                       <div class="form-group">
                                                          <div class="col-lg-12" style="">
                                                            <label>Секрет 2 FK</label>
                                                            <input type="text" class="form-control" id="fksecret2" placeholder="Секрет 2 FK" value="<?=$fk_secret_2?>"/>
                                                          </div>
                                                        </div>
                     
                      
                      </div>
                     
                      </center>
                        </div></div></div>
                        
              </div>

   
  
               



          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="https://vk.com/gscript_s" target="_blank">GScript</a>. Все права защищены.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Сделано с  <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
 
  </body>
</html>
<?php } else { header('Location: ../error404'); } ?>