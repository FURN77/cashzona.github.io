<?php
require("../inc/site_config.php");
require("../inc/bd.php");
session_start();
$sid = $_SESSION['hash'];

// проверка на админа
$admin_check = "SELECT * FROM kot_user WHERE hash = '$sid'";
$result_admin = mysql_query($admin_check);
$row = mysql_fetch_array($result_admin);
if($row)
{	
$last_check = $row['admin'];
}
// остальное - вывод юзеров и прочее




// проверка на админа
$admin_check = "SELECT * FROM kot_user WHERE hash = '$sid'";
$result_admin = mysql_query($admin_check);
$row = mysql_fetch_array($result_admin);
if($row)
{	
    $img = $row['img'];
    $vk_name = $row['vk_name'];
    
$last_check = $row['admin'];
}
if($last_check==1){
$status='Администратор';
}
if($last_check==0){
$status='Игрок';
}
if($last_check==2){
$status='Модератор';
}$sql_select1 = "SELECT COUNT(*) FROM kot_user";
$result1 = mysql_query($sql_select1);
$row = mysql_fetch_array($result1);
if($row)
{	
$users = $row['COUNT(*)'];
}
$sql_select22 = "SELECT COUNT(*) FROM kot_games";
$result22 = mysql_query($sql_select22);
$row = mysql_fetch_array($result22);
if($row)
{	
$games = $row['COUNT(*)'];
}
$sql_select33 = "SELECT SUM(suma) FROM kot_payments WHERE status=2";
$result33 = mysql_query($sql_select33);
$row = mysql_fetch_array($result33);
if($row)
{	
$deps = $row['SUM(suma)'];
}
$sql_select44 = "SELECT SUM(sum) FROM kot_withdraws";
$result44 = mysql_query($sql_select44);
$row = mysql_fetch_array($result44);
if($row)
{	
$withdraws = $row['SUM(sum)'];
}
if($deps == '') {
  $deps = 0;
}
if($withdraws == '') {
  $withdraws = 0;
}
$sql_select5 = "SELECT * FROM kot_withdraws ORDER BY id + 0 DESC";
$result5 = mysql_query($sql_select5);
if($last_check == 1) {
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    
    <link rel="stylesheet" href="../css/5style.css">
   
    <!-- Темная тема 
     <link rel="stylesheet" href=" https://www.bootstrapdash.com/demo/purple/jquery/template/assets/css/demo_2/style.css">
     ------>
     <!-- CВетлая тема -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!--  -------------->
    
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
          <a class="navbar-brand brand-logo-mini" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
           <script>
           
           
             function offliner() {

  $('#mybalance').load('/inc/main.php #mybalance');
		}
		
		setInterval('offliner()',3000);   
                             
                              </script>
          
         
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="<?=$img;?>" alt="image">
                  <span class="availability-status online"></span>
                </div>
                
              </a>
             
            </li>
            
            
            <li class="nav-item dropdown">
             <div>
                 <span id="mybalance"><?=$balance;?></span><i class="mdi mdi-coin"></i>
               
              </div>
            </li>
          
       
          
          
            
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="<?=$img;?>" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?=$vk_name;?></span>
                  <span class="text-secondary text-small"><?=$status;?></span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/';" >
                <span class="menu-title">Главная страница сайта</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
          
            <li class="nav-item ">
                
              <a class="nav-link "  href = "/admin/index.php">
                <span class="menu-title">Настройки</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a onclick="location.href = '/admin/users';"  class="nav-link ">
                <span class="menu-title">Пользователи</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/promo';" >
                <span class="menu-title">Промокоды</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
             <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/deps';" >
                <span class="menu-title">Пополнения</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/withdraws';" >
                <span class="menu-title">Выплаты</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
              <li class="nav-item active">
              <a class="nav-link" onclick="location.href = '/admin/stat';" >
                <span class="menu-title">Статистика сайта</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/percent';" >
                <span class="menu-title">Шансы</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
            
              </span>
            </li>
          </ul>
        </nav>
      
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
<div class="row" id="refs" >
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Статистика 
                   
                  </h4>
                   <center>

<table id="withdraws-tbl" class="table-responsive-sm table table-striped- table-bordered table-hover table-checkable">
                    
				<thead>
					<tr>
						<th class="tbl-name">Всего игр</th>
                        <th class="tbl-name">Пользователей</th>
                        <th class="tbl-name">Пополнено</th>
						<th class="tbl-name">На выводе / выплачено</th>
						
						
						
					</tr>
				</thead>
                      <tbody>
                      <tr role='row' class='odd'>
<td class='sorting_1' tabindex='0'><?=$games?></td>
<td class='sorting_1' tabindex='0'><?=$users?></td>
<td class='sorting_1' tabindex='0'><?=$deps?> Р</td>
<td class='sorting_1' tabindex='0'><?=$withdraws?> Р</td>

</tr>

                      </tbody>
			</table>
                      </center>
                       
                        </div></div></div>
                        
              </div>

   
  
               



          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="https://vk.com/gscript_s" target="_blank">GScript</a>. Все права защищены.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Сделано с  <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
 
  </body>
</html>
<?php } else { header('Location: ../error404'); } ?>