<?
require('inc/site_config.php');
require('inc/bd.php');
session_start();
$sid = $_SESSION['hash'];
$sql_select = "SELECT * FROM kot_user WHERE hash='$sid'";
$result = mysql_query($sql_select);
$row = mysql_fetch_array($result);
if($row)
{	
$login = $row['login'];
$bala = $row['balance'];
$user_id = $row['id'];
}

$sql_select = "SELECT * FROM kot_payments WHERE user_id='$user_id' and status=1 ORDER BY id DESC LIMIT 1";
$result = mysql_query($sql_select);
$row = mysql_fetch_array($result);
if($row)
{	
$id_dep = $row['id'];
$suma = $row['suma'];
$transaction = $row['transaction'];
$link = $row['link'];
$description = $row['description'];
}
$link1 = explode("/", $link);
$link11 = $link1[3];
$link1 = 'https://api.swiftpay.ru/order/'.$link11;
//   https://api.swiftpay.ru/order/wcpq-qtod-secb-dytm
?>
<html lang="en" class=" ">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="/favicon.ico">
    <meta name="viewport" content="width=600">
    <meta name="theme-color" content="#000000">
    <meta name="description" content="Страница оплаты счета SWIFTPAY">
    <link rel="shortcut icon" href="https://pay.swiftpay.ru/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="logo192.png">
    <link rel="manifest" href="/manifest.json">
    <title>Ожидание оплаты <?=$sitename;?></title>
    <link href="https://pay.swiftpay.ru/static/css/2.4344fd08.chunk.css" rel="stylesheet">
    <link href="https://pay.swiftpay.ru/static/css/main.88282ad1.chunk.css" rel="stylesheet">
    <style data-emotion="css"></style>
</head>

<body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root">
        <div class="app">
            <div class="main animated">
                <div class="blockLoader hidden">
                    <div class="inner">
                        <div class="rect1"></div>
                        <div class="rect2"></div>
                        <div class="rect3"></div>
                        <div class="rect4"></div>
                        <div class="rect5"></div>
                    </div>
                </div>
                <div class="left" style="display: flex;">
                    <div class="name"><a target="_blank" rel="noopener noreferrer" href="https://vk.com/gscript_s">GameWin</a></div>
                    <div class="amount">
                        <div class="toPay">К зачислению:</div>
                        <div class="total"><?=$suma;?></span></div>
                    </div>
                    <div class="powered">Powered by <a href="https://vk.com/gscript_s" target="_blank" rel="noopener noreferrer">GScript</a></div>
                </div>
                <div class="right">
                    <div class="blockLoader hidden">
                        <div class="inner">
                            <div class="rect1"></div>
                            <div class="rect2"></div>
                            <div class="rect3"></div>
                            <div class="rect4"></div>
                            <div class="rect5"></div>
                        </div>
                    </div>
                    <a class="logotype" href="https://vk.com/gscript_s" target="_blank" rel="noopener noreferrer"><img src="images/logo.png" alt="swiftpay"></a>
                    <div>
                       
                        
                        <div class="email" style="text-align:center;font-size:20px;padding:50px;border:2px solid red;border-radius:10px;">
                            Ожидаем средства, если вы ждёте очень долго, то нажмите на кнопку ниже, либо напишите нам в группу вк
                    
                        </div>
                        
                    </div><center>
                    <div class="buttons">
                       <center>
                        <div class="">
                            <div class="btn payAnimation" onclick="check()">Зачислить средства</div>
                        </div>
                        </center>
                    </div>
                    </center>
                </div>
            </div>
            <div>
                <script type="text/javascript" async="" src="https://mc.yandex.ru/metrika/watch.js"></script>
            </div>
        </div>
    </div>
    <script>
        ! function(p) {
            function e(e) {
                for (var r, t, n = e[0], o = e[1], u = e[2], l = 0, a = []; l < n.length; l++) t = n[l], Object.prototype.hasOwnProperty.call(i, t) && i[t] && a.push(i[t][0]), i[t] = 0;
                for (r in o) Object.prototype.hasOwnProperty.call(o, r) && (p[r] = o[r]);
                for (s && s(e); a.length;) a.shift()();
                return c.push.apply(c, u || []), f()
            }

            function f() {
                for (var e, r = 0; r < c.length; r++) {
                    for (var t = c[r], n = !0, o = 1; o < t.length; o++) {
                        var u = t[o];
                        0 !== i[u] && (n = !1)
                    }
                    n && (c.splice(r--, 1), e = l(l.s = t[0]))
                }
                return e
            }
            var t = {},
                i = {
                    1: 0
                },
                c = [];

            function l(e) {
                if (t[e]) return t[e].exports;
                var r = t[e] = {
                    i: e,
                    l: !1,
                    exports: {}
                };
                return p[e].call(r.exports, r, r.exports, l), r.l = !0, r.exports
            }
            l.m = p, l.c = t, l.d = function(e, r, t) {
                l.o(e, r) || Object.defineProperty(e, r, {
                    enumerable: !0,
                    get: t
                })
            }, l.r = function(e) {
                "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                    value: "Module"
                }), Object.defineProperty(e, "__esModule", {
                    value: !0
                })
            }, l.t = function(r, e) {
                if (1 & e && (r = l(r)), 8 & e) return r;
                if (4 & e && "object" == typeof r && r && r.__esModule) return r;
                var t = Object.create(null);
                if (l.r(t), Object.defineProperty(t, "default", {
                        enumerable: !0,
                        value: r
                    }), 2 & e && "string" != typeof r)
                    for (var n in r) l.d(t, n, function(e) {
                        return r[e]
                    }.bind(null, n));
                return t
            }, l.n = function(e) {
                var r = e && e.__esModule ? function() {
                    return e.default
                } : function() {
                    return e
                };
                return l.d(r, "a", r), r
            }, l.o = function(e, r) {
                return Object.prototype.hasOwnProperty.call(e, r)
            }, l.p = "/";
            var r = this.webpackJsonppay = this.webpackJsonppay || [],
                n = r.push.bind(r);
            r.push = e, r = r.slice();
            for (var o = 0; o < r.length; o++) e(r[o]);
            var s = n;
            f()
        }([])
    </script>
    <script src="/static/js/2.14ff2555.chunk.js"></script>
    <script src="https://pay.swiftpay.ru/static/js/main.5dc3e923.chunk.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  
   <script>
check()
        function check() {
          
        
   $.ajax({
                                                                                type: 'GET',
                                                                                url: '<?=$link1;?>',

                                                        success: function(data) {
                                            var data1 = JSON.stringify(data);
                                            var obj1 = jQuery.parseJSON(data1);
                                            var status = obj1.data.status;
                                            var name = obj1.data.name;
                                            var description = obj1.data.description;
                                            var amount = obj1.data.amount;
                                          if (status == 1){
                                             
                                             $.ajax({
                                                                                type: 'POST',
                                                                                url: '../action.php',
data:{
    type:"checkpay",
    name: name,
    description: description,
    amount: amount,
      status: status,
},
                                                        success: function(data) {
                                            
                                            var obj11 = jQuery.parseJSON(data);
                                           if(obj11.success == "success"){
                                              window.location.href = "/";
                                              
                                              
                                           }
                                          
                                          
                                          
                                          
                                            }   
                                            });
                                             
                                             
                                          }
                                        }   
   });
   
}
   </script>
</body>

</html>