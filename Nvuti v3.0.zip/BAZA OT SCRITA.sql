-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 15 2020 г., 09:44
-- Версия сервера: 5.7.23-24
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `u0968550_test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `kot_admin`
--

CREATE TABLE IF NOT EXISTS `kot_admin` (
  `id` int(11) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `zarabotok` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kot_admin`
--

INSERT INTO `kot_admin` (`id`, `bank`, `zarabotok`) VALUES
(1, '447.1299999999989', '363.1400000000022');

-- --------------------------------------------------------

--
-- Структура таблицы `kot_bots`
--

CREATE TABLE IF NOT EXISTS `kot_bots` (
  `id` int(11) NOT NULL,
  `bot_login` varchar(50) NOT NULL,
  `bot_min_bet` varchar(50) NOT NULL DEFAULT '1',
  `bot_max_bet` varchar(50) NOT NULL DEFAULT '100',
  `status` varchar(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `kot_chance`
--

CREATE TABLE IF NOT EXISTS `kot_chance` (
  `id` int(11) NOT NULL,
  `per` varchar(2) NOT NULL,
  `chance` varchar(3) NOT NULL,
  `is_drop` varchar(1) NOT NULL DEFAULT '1',
  `active` varchar(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `kot_chat`
--

CREATE TABLE IF NOT EXISTS `kot_chat` (
  `id` int(11) NOT NULL,
  `vk_id` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `login` text NOT NULL,
  `photo` text NOT NULL,
  `mess` text NOT NULL,
  `prava` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `kot_config`
--

CREATE TABLE IF NOT EXISTS `kot_config` (
  `id` int(11) NOT NULL,
  `sitename` varchar(50) NOT NULL DEFAULT 'KotDev',
  `sitedomen` varchar(50) NOT NULL,
  `sitegroup` varchar(50) NOT NULL,
  `sitesupport` varchar(150) NOT NULL,
  `sitekey` varchar(150) NOT NULL,
  `sitemail` varchar(50) NOT NULL,
  `min_bonus_size` varchar(50) NOT NULL DEFAULT '1',
  `max_bonus_size` varchar(50) NOT NULL DEFAULT '10',
  `min_withdraw_sum` varchar(50) NOT NULL DEFAULT '50',
  `bonus_reg` varchar(50) NOT NULL DEFAULT '5',
  `fk_id` varchar(50) NOT NULL,
  `fk_secret_1` varchar(50) NOT NULL,
  `fk_secret_2` varchar(50) NOT NULL,
  `dep_withdraw` varchar(50) NOT NULL DEFAULT '0',
  `min_bet` varchar(50) NOT NULL DEFAULT '1',
  `max_bet` varchar(50) NOT NULL DEFAULT '1000',
  `min_per` varchar(50) NOT NULL DEFAULT '1',
  `max_per` varchar(50) NOT NULL DEFAULT '95',
  `fake_online` varchar(50) NOT NULL DEFAULT '0',
  `fake_interval` varchar(50) NOT NULL DEFAULT '0',
  `min_sum_dep` varchar(50) NOT NULL DEFAULT '1',
  `id_vk` varchar(500) NOT NULL,
  `token_vk` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kot_config`
--

INSERT INTO `kot_config` (`id`, `sitename`, `sitedomen`, `sitegroup`, `sitesupport`, `sitekey`, `sitemail`, `min_bonus_size`, `max_bonus_size`, `min_withdraw_sum`, `bonus_reg`, `fk_id`, `fk_secret_1`, `fk_secret_2`, `dep_withdraw`, `min_bet`, `max_bet`, `min_per`, `max_per`, `fake_online`, `fake_interval`, `min_sum_dep`, `id_vk`, `token_vk`) VALUES
(1, 'GScript', 'ru.com', '/', '', '', '/', '1', '20', '20', '2', '', '', '', '5', '1', '100000', '1', '95', '0', '555555555', '1', '180270822', 'c74fa6f09187e93980be4d470ab2bb919d220346982e8f07905ed4ed916c2481a31be0983f10570341b5c');

-- --------------------------------------------------------

--
-- Структура таблицы `kot_games`
--

CREATE TABLE IF NOT EXISTS `kot_games` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `cel` varchar(50) NOT NULL,
  `sum` varchar(50) NOT NULL,
  `chance` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `win_summa` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kot_games`
--

INSERT INTO `kot_games` (`id`, `user_id`, `login`, `number`, `cel`, `sum`, `chance`, `type`, `win_summa`) VALUES
(1, '1', 'Gscript', '681733', '0 - 899999', '1', 90, 'win', '1.11'),
(2, '1', 'Gscript', '822309', '0 - 9999', '1', 1, 'lose', '0'),
(3, '1', 'Gscript', '729237', '0 - 9999', '1', 1, 'lose', '0'),
(4, '1', 'Gscript', '715538', '990000 - 999999', '1', 1, 'lose', '0'),
(5, '1', 'Gscript', '833418', '0 - 899999', '1', 90, 'win', '1.11'),
(6, '1', 'Gscript', '460110', '100000 - 999999', '1', 90, 'win', '1.11'),
(7, '1', 'Gscript', '110772', '100000 - 999999', '1', 90, 'win', '1.11'),
(8, '1', 'Gscript', '770568', '0 - 899999', '1', 90, 'win', '1.11'),
(9, '1', 'Gscript', '233348', '0 - 899999', '1', 90, 'win', '1.11'),
(10, '1', 'Gscript', '256938', '0 - 899999', '1', 90, 'win', '1.11'),
(11, '1', 'Gscript', '978414', '0 - 899999', '1', 90, 'lose', '0'),
(12, '1', 'Gscript', '341747', '0 - 899999', '1', 90, 'win', '1.11'),
(13, '1', 'Gscript', '832419', '0 - 899999', '1', 90, 'win', '1.11'),
(14, '1', 'Gscript', '177845', '0 - 899999', '1', 90, 'win', '1.11'),
(15, '1', 'Gscript', '824462', '0 - 899999', '1', 90, 'win', '1.11'),
(16, '1', 'Gscript', '405431', '0 - 899999', '1', 90, 'win', '1.11'),
(17, '1', 'Gscript', '873287', '0 - 899999', '1', 90, 'win', '1.11'),
(18, '1', 'Gscript', '433628', '0 - 899999', '1', 90, 'win', '1.11'),
(19, '1', 'Gscript', '937797', '0 - 899999', '1', 90, 'lose', '0'),
(20, '1', 'Gscript', '482770', '0 - 899999', '1', 90, 'win', '1.11'),
(21, '1', 'Gscript', '1799', '0 - 899999', '1', 90, 'win', '1.11'),
(22, '1', 'Gscript', '265509', '0 - 899999', '1', 90, 'win', '1.11'),
(23, '1', 'Gscript', '230681', '0 - 899999', '1', 90, 'win', '1.11'),
(24, '1', 'Gscript', '394541', '0 - 899999', '1', 90, 'win', '1.11'),
(25, '1', 'Gscript', '934214', '0 - 899999', '1', 90, 'lose', '0'),
(26, '1', 'Gscript', '959916', '0 - 899999', '1', 90, 'lose', '0'),
(27, '1', 'Gscript', '185275', '0 - 899999', '1', 90, 'win', '1.11'),
(28, '1', 'Gscript', '749008', '0 - 899999', '1', 90, 'win', '1.11'),
(29, '3', 'vgnvhnjbh', '305368', '0 - 899999', '2', 90, 'win', '2.22'),
(30, '3', 'vgnvhnjbh', '439412', '0 - 899999', '2.22', 90, 'win', '2.47'),
(31, '3', 'vgnvhnjbh', '637023', '0 - 449999', '2.47', 45, 'lose', '0'),
(32, '6', 'Fkjfjtjtj', '597776', '100000 - 999999', '1', 90, 'win', '1.11'),
(33, '6', 'Fkjfjtjtj', '522112', '100000 - 999999', '1', 90, 'win', '1.11'),
(34, '6', 'Fkjfjtjtj', '395883', '100000 - 999999', '1', 90, 'win', '1.11'),
(35, '6', 'Fkjfjtjtj', '351190', '100000 - 999999', '1', 90, 'win', '1.11'),
(36, '6', 'Fkjfjtjtj', '841525', '100000 - 999999', '1', 90, 'win', '1.11'),
(37, '6', 'Fkjfjtjtj', '684695', '100000 - 999999', '1', 90, 'win', '1.11'),
(38, '6', 'Fkjfjtjtj', '84352', '100000 - 999999', '1', 90, 'lose', '0'),
(39, '6', 'Fkjfjtjtj', '889415', '100000 - 999999', '1', 90, 'win', '1.11'),
(40, '6', 'Fkjfjtjtj', '564070', '100000 - 999999', '1', 90, 'win', '1.11'),
(41, '6', 'Fkjfjtjtj', '969359', '100000 - 999999', '1', 90, 'win', '1.11'),
(42, '6', 'Fkjfjtjtj', '57266', '100000 - 999999', '1', 90, 'lose', '0'),
(43, '1', 'Gscript', '142579', '0 - 899999', '1', 90, 'win', '1.11'),
(44, '1', 'Gscript', '696777', '100000 - 999999', '1', 90, 'win', '1.11'),
(45, '1', 'Gscript', '901807', '0 - 899999', '1', 90, 'lose', '0'),
(46, '1', 'Gscript', '886178', '0 - 899999', '1', 90, 'win', '1.11');

-- --------------------------------------------------------

--
-- Структура таблицы `kot_payments`
--

CREATE TABLE `kot_payments` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `suma` int(50) NOT NULL,
  `data` varchar(50) NOT NULL,
  `qiwi` varchar(50) NOT NULL,
  `transaction` varchar(50) NOT NULL,
  `beforepay` float NOT NULL,
  `afterpay` float NOT NULL,
  `status` int(1) NOT NULL,
  `link` varchar(5555) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Структура таблицы `kot_promo`
--

CREATE TABLE IF NOT EXISTS `kot_promo` (
  `id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `is_admin` varchar(1) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `sum` varchar(50) NOT NULL,
  `active` varchar(50) NOT NULL,
  `actived` varchar(50) NOT NULL DEFAULT '0',
  `id_active` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `kot_user`
--

CREATE TABLE IF NOT EXISTS `kot_user` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `vk_name` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `balance` varchar(50) NOT NULL,
  `img` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `social` varchar(150) NOT NULL,
  `bdate` varchar(50) NOT NULL,
  `online` varchar(1) NOT NULL DEFAULT '1',
  `admin` varchar(1) NOT NULL DEFAULT '0',
  `ban` varchar(1) NOT NULL DEFAULT '0',
  `sliv` varchar(1) NOT NULL DEFAULT '0',
  `win` varchar(1) NOT NULL DEFAULT '0',
  `ref_id` varchar(11) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `date_reg` varchar(50) NOT NULL,
  `online_time` varchar(50) NOT NULL,
  `chat_ban` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `kot_user`
--

INSERT INTO `kot_user` (`id`, `login`, `vk_name`, `pass`, `balance`, `img`, `hash`, `social`, `bdate`, `online`, `admin`, `ban`, `sliv`, `win`, `ref_id`, `ip`, `date_reg`, `online_time`, `chat_ban`) VALUES
(1, 'Gscript', 'Андрей Колбин', '100000', '1000028.89', 'https://sun9-7.userapi.com/c857332/v857332280/cb089/6N-CFJSYuPc.jpg?ava=1', 'http://vk.com/id515504259', 'http://vk.com/id515504259', '15052020', '1', '1', '0', '0', '0', '', '176.96.82.202', '14.05.2020', '1589525050', '0'),
(2, 'Shahov', 'Максим Стрелков', 'fkdk300', '0', 'https://vk.com/images/camera_200.png?ava=1', 'http://vk.com/id533891639', 'http://vk.com/id533891639', '', '0', '0', '0', '0', '0', '', '89.113.136.200', '14.05.2020', '1589447933', '0'),
(3, 'vgnvhnjbh', 'Тимофей Шустриков', 'jbhmkhjkj', '0', 'https://sun1-22.userapi.com/c857136/v857136662/199b40/Ncu_AY93_eY.jpg?ava=1', 'http://vk.com/id481159631', 'http://vk.com/id481159631', '', '0', '0', '0', '0', '0', '', '5.166.15.186', '14.05.2020', '1589451936', '0'),
(4, 'nonametop', 'Илья Волков', 'fewgvgegfv', '2', 'https://sun9-58.userapi.com/c855132/v855132547/212986/OciOrdT38ds.jpg?ava=1', 'http://vk.com/id541555590', 'http://vk.com/id541555590', '', '0', '0', '0', '0', '0', '1', '176.96.82.202', '14.05.2020', '1589454684', '0'),
(5, 'Admin', 'glamcha top', 'admin1', '2.9', 'https://lh3.googleusercontent.com/a-/AOh14GiaxOO7VxdtmQo9tayJ1Tk3ZgckJ9IqUi_neq7D', 'https://plus.google.com/u/0/105126460604723873034/', 'https://plus.google.com/u/0/105126460604723873034/', '', '0', '0', '0', '0', '0', '', '80.83.237.9', '14.05.2020', '1589453171', '0'),
(6, 'Fkjfjtjtj', 'Данил Зобков', 'jfjgjfjf', '0.99', 'https://sun1-18.userapi.com/g9CoBZmOMU-257yOfPNRQagH-FKu-UWCRKS7aQ/f5jg8kYe5Aw.jpg?ava=1', 'http://vk.com/id304297886', 'http://vk.com/id304297886', '', '0', '0', '0', '0', '0', '', '176.59.65.173', '14.05.2020', '1589462471', '0'),
(7, '1234456', 'Александр Скриптеров', '1123457654', '0.18', 'https://sun9-17.userapi.com/c206524/v206524518/ecbc4/lHlcqjbgqrI.jpg?ava=1', 'http://vk.com/id586589172', 'http://vk.com/id586589172', '', '0', '0', '0', '0', '0', '', '109.252.37.61', '14.05.2020', '1589465867', '0'),
(8, 'RGTGRREGT', 'Дмитрий Малахов', 'YTHTYHUT', '0', 'https://sun1-27.userapi.com/tLtZxO8oPq6ZWP1o2465mct3ALnMGhX2HJl3Vw/rISJVa2ZPVI.jpg?ava=1', 'http://vk.com/id525320363', 'http://vk.com/id525320363', '', '0', '0', '0', '0', '0', '', '90.151.80.199', '14.05.2020', '1589473810', '0'),
(9, 'Fkfktjtj', 'Игорь Фоменко', 'tktkjtjtj', '1.84', 'https://sun1-15.userapi.com/CDXOFY99_jOqbWManla1ic3tRG18lmm8TeiT6g/Q5IZ51YeDsA.jpg?ava=1', 'http://vk.com/id575719294', 'http://vk.com/id575719294', '', '0', '0', '0', '0', '0', '', '176.59.65.124', '15.05.2020', '1589521022', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `kot_withdraws`
--

CREATE TABLE IF NOT EXISTS `kot_withdraws` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `ps` varchar(50) NOT NULL,
  `wallet` varchar(50) NOT NULL,
  `sum` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT '0',
  `fake` varchar(1) NOT NULL DEFAULT '0',
  `login_fake` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `mines-game`
--

CREATE TABLE IF NOT EXISTS `mines-game` (
  `id` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `login` text NOT NULL,
  `num_mines` int(11) NOT NULL,
  `bet` int(11) NOT NULL,
  `mines` text NOT NULL,
  `click` text NOT NULL,
  `onOff` text NOT NULL,
  `result` text NOT NULL,
  `step` int(11) NOT NULL,
  `win` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `mines-game`
--

INSERT INTO `mines-game` (`id`, `id_users`, `login`, `num_mines`, `bet`, `mines`, `click`, `onOff`, `result`, `step`, `win`) VALUES
(1, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:19;i:1;i:18;i:2;i:2;}', 'a:5:{i:0;s:2:"10";i:1;s:1:"7";i:2;s:1:"1";i:3;s:2:"25";i:4;s:2:"13";}', '2', '1', 5, 1.3),
(2, 2, 'Shahov', 5, 1, 'a:5:{i:0;i:13;i:1;i:20;i:2;i:5;i:3;i:2;i:4;i:21;}', 'a:0:{}', '2', '1', 0, 0),
(3, 2, 'Shahov', 5, 1, 'a:5:{i:0;i:4;i:1;i:25;i:2;i:7;i:3;i:24;i:4;i:14;}', 'a:6:{i:0;s:2:"11";i:1;s:2:"17";i:2;s:2:"18";i:3;s:2:"19";i:4;s:2:"20";i:5;s:2:"15";}', '2', '1', 6, 3.84),
(4, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:19;i:1;i:24;i:2;i:22;}', 'a:1:{i:0;s:2:"10";}', '2', '1', 1, 1.03),
(5, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:21;i:1;i:4;i:2;i:20;}', 'a:2:{i:0;s:1:"9";i:1;s:2:"17";}', '2', '1', 2, 1.06),
(6, 1, 'Gscript', 10, 1, 'a:10:{i:0;i:12;i:1;i:1;i:2;i:13;i:3;i:4;i:4;i:23;i:5;i:25;i:6;i:19;i:7;i:18;i:8;i:15;i:9;i:22;}', 'a:0:{}', '2', '1', 0, 0),
(7, 5, 'Admin', 3, 1, 'a:3:{i:0;i:12;i:1;i:10;i:2;i:5;}', 'a:6:{i:0;s:2:"13";i:1;s:1:"7";i:2;s:2:"19";i:3;s:2:"17";i:4;s:1:"9";i:5;s:1:"1";}', '2', '1', 6, 1.45),
(8, 5, 'Admin', 3, 1, 'a:3:{i:0;i:20;i:1;i:10;i:2;i:23;}', 'a:9:{i:0;s:2:"25";i:1;s:1:"1";i:2;s:1:"5";i:3;s:2:"21";i:4;s:2:"13";i:5;s:1:"7";i:6;s:2:"19";i:7;s:1:"9";i:8;s:2:"17";}', '2', '1', 9, 2.9),
(9, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:7;i:1;i:1;i:2;i:21;}', 'a:7:{i:0;s:2:"10";i:1;s:1:"6";i:2;s:2:"20";i:3;s:2:"16";i:4;s:1:"3";i:5;s:2:"23";i:6;s:2:"13";}', '2', '1', 7, 1.67),
(10, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:15;i:1;i:14;i:2;i:22;}', 'a:0:{}', '2', '1', 0, 0),
(11, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:10;i:1;i:24;i:2;i:8;i:3;i:18;i:4;i:25;i:5;i:6;i:6;i:2;i:7;i:17;i:8;i:15;i:9;i:13;i:10;i:9;i:11;i:3;i:12;i:22;i:13;i:14;i:14;i:20;i:15;i:21;i:16;i:16;i:17;i:11;i:18;i:7;i:19;i:19;i:20;i:12;i:21;i:1;i:22;i:23;i:23;i:4;}', 'a:0:{}', '2', '1', 0, 0),
(12, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:1;i:1;i:15;i:2;i:18;}', 'a:1:{i:0;s:1:"5";}', '2', '1', 1, 1.03),
(13, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:21;i:1;i:9;i:2;i:13;i:3;i:6;i:4;i:25;i:5;i:14;i:6;i:18;i:7;i:16;i:8;i:19;i:9;i:15;i:10;i:2;i:11;i:1;i:12;i:22;i:13;i:23;i:14;i:11;i:15;i:5;i:16;i:20;i:17;i:12;i:18;i:7;i:19;i:17;i:20;i:10;i:21;i:24;i:22;i:8;i:23;i:3;}', 'a:0:{}', '2', '1', 0, 0),
(14, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:3;i:1;i:13;i:2;i:7;i:3;i:15;i:4;i:19;i:5;i:10;i:6;i:9;i:7;i:22;i:8;i:23;i:9;i:6;i:10;i:8;i:11;i:4;i:12;i:12;i:13;i:18;i:14;i:11;i:15;i:21;i:16;i:5;i:17;i:24;i:18;i:14;i:19;i:17;i:20;i:16;i:21;i:2;i:22;i:20;i:23;i:1;}', 'a:0:{}', '2', '1', 0, 0),
(15, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:12;i:1;i:8;i:2;i:22;i:3;i:4;i:4;i:20;i:5;i:25;i:6;i:24;i:7;i:2;i:8;i:5;i:9;i:1;i:10;i:6;i:11;i:18;i:12;i:11;i:13;i:7;i:14;i:17;i:15;i:21;i:16;i:13;i:17;i:14;i:18;i:3;i:19;i:15;i:20;i:16;i:21;i:23;i:22;i:9;i:23;i:10;}', 'a:0:{}', '2', '1', 0, 0),
(16, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:11;i:1;i:14;i:2;i:20;i:3;i:7;i:4;i:5;i:5;i:16;i:6;i:1;i:7;i:23;i:8;i:24;i:9;i:6;i:10;i:17;i:11;i:12;i:12;i:21;i:13;i:15;i:14;i:18;i:15;i:13;i:16;i:25;i:17;i:19;i:18;i:10;i:19;i:2;i:20;i:9;i:21;i:22;i:22;i:8;i:23;i:3;}', 'a:0:{}', '2', '1', 0, 0),
(17, 1, 'Gscript', 24, 1, 'a:24:{i:0;i:19;i:1;i:14;i:2;i:6;i:3;i:17;i:4;i:18;i:5;i:11;i:6;i:8;i:7;i:7;i:8;i:15;i:9;i:5;i:10;i:1;i:11;i:23;i:12;i:9;i:13;i:4;i:14;i:22;i:15;i:16;i:16;i:10;i:17;i:24;i:18;i:12;i:19;i:3;i:20;i:21;i:21;i:2;i:22;i:20;i:23;i:13;}', 'a:1:{i:0;s:2:"25";}', '2', '1', 1, 23.8),
(18, 7, '1234456', 3, 1, 'a:3:{i:0;i:18;i:1;i:4;i:2;i:15;}', 'a:4:{i:0;s:1:"5";i:1;s:1:"9";i:2;s:2:"14";i:3;s:2:"13";}', '2', '1', 4, 1.18),
(19, 7, '1234456', 3, 1, 'a:3:{i:0;i:1;i:1;i:21;i:2;i:10;}', 'a:3:{i:0;s:1:"4";i:1;s:1:"3";i:2;s:1:"5";}', '2', '1', 3, 1.12),
(20, 7, '1234456', 3, 1, 'a:3:{i:0;i:13;i:1;i:11;i:2;i:20;}', 'a:2:{i:0;s:1:"1";i:1;s:1:"6";}', '2', '1', 2, 1.06),
(21, 8, 'RGTGRREGT', 3, 1, 'a:3:{i:0;i:21;i:1;i:24;i:2;i:18;}', 'a:11:{i:0;s:1:"1";i:1;s:1:"6";i:2;s:1:"7";i:3;s:1:"8";i:4;s:1:"3";i:5;s:2:"11";i:6;s:2:"16";i:7;s:2:"17";i:8;s:2:"22";i:9;s:2:"23";i:10;s:1:"5";}', '2', '1', 11, 6),
(22, 8, 'RGTGRREGT', 3, 1, 'a:3:{i:0;i:22;i:1;i:7;i:2;i:20;}', 'a:3:{i:0;s:1:"6";i:1;s:1:"2";i:2;s:1:"1";}', '2', '1', 3, 1.12),
(23, 1, 'Gscript', 5, 1, 'a:5:{i:0;i:12;i:1;i:9;i:2;i:19;i:3;i:7;i:4;i:16;}', 'a:0:{}', '2', '1', 0, 0),
(24, 1, 'Gscript', 5, 1, 'a:5:{i:0;i:8;i:1;i:16;i:2;i:14;i:3;i:15;i:4;i:1;}', 'a:0:{}', '2', '1', 0, 0),
(25, 1, 'Gscript', 10, 1, 'a:10:{i:0;i:10;i:1;i:12;i:2;i:11;i:3;i:16;i:4;i:5;i:5;i:6;i:6;i:8;i:7;i:13;i:8;i:20;i:9;i:23;}', 'a:1:{i:0;s:2:"19";}', '2', '1', 1, 1.38),
(26, 1, 'Gscript', 10, 1, 'a:10:{i:0;i:2;i:1;i:6;i:2;i:19;i:3;i:3;i:4;i:11;i:5;i:10;i:6;i:20;i:7;i:13;i:8;i:25;i:9;i:23;}', 'a:0:{}', '2', '1', 0, 0),
(27, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:5;i:1;i:18;i:2;i:13;}', 'a:1:{i:0;s:2:"14";}', '2', '1', 1, 1.03),
(28, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:24;i:1;i:19;i:2;i:8;}', 'a:5:{i:0;s:1:"9";i:1;s:1:"1";i:2;s:2:"21";i:3;s:2:"25";i:4;s:2:"13";}', '2', '1', 5, 1.3),
(29, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:8;i:1;i:4;i:2;i:6;}', 'a:14:{i:0;s:1:"1";i:1;s:1:"3";i:2;s:1:"5";i:3;s:1:"9";i:4;s:1:"7";i:5;s:2:"11";i:6;s:2:"13";i:7;s:2:"15";i:8;s:2:"19";i:9;s:2:"17";i:10;s:2:"21";i:11;s:2:"23";i:12;s:2:"24";i:13;s:2:"25";}', '2', '1', 14, 13.24),
(30, 1, 'Gscript', 5, 1, 'a:5:{i:0;i:21;i:1;i:2;i:2;i:23;i:3;i:20;i:4;i:13;}', 'a:0:{}', '2', '1', 0, 0),
(31, 1, 'Gscript', 5, 1, 'a:5:{i:0;i:16;i:1;i:25;i:2;i:7;i:3;i:23;i:4;i:22;}', 'a:3:{i:0;s:2:"21";i:1;s:2:"11";i:2;s:1:"1";}', '2', '1', 3, 1.91),
(32, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:22;i:1;i:7;i:2;i:14;}', 'a:3:{i:0;s:1:"5";i:1;s:1:"3";i:2;s:1:"1";}', '2', '1', 3, 1.12),
(33, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:1;i:1;i:6;i:2;i:7;}', 'a:1:{i:0;s:1:"9";}', '2', '1', 1, 1.03),
(34, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:5;i:1;i:15;i:2;i:19;}', 'a:3:{i:0;s:1:"3";i:1;s:2:"13";i:2;s:2:"23";}', '2', '1', 3, 1.12),
(35, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:11;i:1;i:16;i:2;i:18;}', 'a:9:{i:0;s:2:"25";i:1;s:2:"19";i:2;s:2:"13";i:3;s:1:"7";i:4;s:1:"1";i:5;s:1:"5";i:6;s:1:"9";i:7;s:2:"17";i:8;s:2:"21";}', '2', '1', 9, 2.9),
(36, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:2;i:1;i:12;i:2;i:8;}', 'a:1:{i:0;s:1:"1";}', '2', '1', 1, 1.03),
(37, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:23;i:1;i:5;i:2;i:25;}', 'a:2:{i:0;s:1:"2";i:1;s:1:"1";}', '2', '1', 2, 1.06),
(38, 1, 'Gscript', 3, 1, 'a:3:{i:0;i:21;i:1;i:2;i:2;i:22;}', 'a:0:{}', '2', '1', 0, 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `kot_admin`
--
ALTER TABLE `kot_admin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_bots`
--
ALTER TABLE `kot_bots`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_chance`
--
ALTER TABLE `kot_chance`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_chat`
--
ALTER TABLE `kot_chat`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_config`
--
ALTER TABLE `kot_config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_games`
--
ALTER TABLE `kot_games`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_payments`
--
ALTER TABLE `kot_payments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_promo`
--
ALTER TABLE `kot_promo`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_user`
--
ALTER TABLE `kot_user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kot_withdraws`
--
ALTER TABLE `kot_withdraws`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `mines-game`
--
ALTER TABLE `mines-game`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `kot_bots`
--
ALTER TABLE `kot_bots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kot_chance`
--
ALTER TABLE `kot_chance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kot_chat`
--
ALTER TABLE `kot_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kot_config`
--
ALTER TABLE `kot_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `kot_games`
--
ALTER TABLE `kot_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT для таблицы `kot_payments`
--
ALTER TABLE `kot_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kot_promo`
--
ALTER TABLE `kot_promo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kot_user`
--
ALTER TABLE `kot_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT для таблицы `kot_withdraws`
--
ALTER TABLE `kot_withdraws`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `mines-game`
--
ALTER TABLE `mines-game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
