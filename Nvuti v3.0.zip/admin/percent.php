<?php

require("../inc/bd.php"); 
require("../inc/site_config.php"); 
session_start();
$sid = $_SESSION['hash'];
$sql_select5 = "SELECT * FROM kot_chance ORDER BY id + 0 DESC";
$result5 = mysql_query($sql_select5);
// проверка на админа
$admin_check = "SELECT * FROM kot_user WHERE hash = '$sid'";
$result_admin = mysql_query($admin_check);
$row = mysql_fetch_array($result_admin);
if($row)
{	
    $img = $row['img'];
    $vk_name = $row['vk_name'];
    
$last_check = $row['admin'];
}
if($last_check==1){
$status='Администратор';
}
if($last_check==0){
$status='Игрок';
}
if($last_check==2){
$status='Модератор';
}
if($last_check == 1) {
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    
    <link rel="stylesheet" href="../css/5style.css">
   
    <!-- Темная тема 
     <link rel="stylesheet" href=" https://www.bootstrapdash.com/demo/purple/jquery/template/assets/css/demo_2/style.css">
     ------>
     <!-- CВетлая тема -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!--  -------------->
    
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
          <a class="navbar-brand brand-logo-mini" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
           <script>
           
           
             function offliner() {

  $('#mybalance').load('/inc/main.php #mybalance');
		}
		
		setInterval('offliner()',3000);   
                             
                              </script>
          
         
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="<?=$img;?>" alt="image">
                  <span class="availability-status online"></span>
                </div>
                
              </a>
             
            </li>
            
            
            <li class="nav-item dropdown">
             <div>
                 <span id="mybalance"><?=$balance;?></span><i class="mdi mdi-coin"></i>
               
              </div>
            </li>
          
       
          
          
            
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="<?=$img;?>" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?=$vk_name;?></span>
                  <span class="text-secondary text-small"><?=$status;?></span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/';" >
                <span class="menu-title">Главная страница сайта</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
          
            <li class="nav-item ">
                
              <a class="nav-link "  href = "/admin/index.php">
                <span class="menu-title">Настройки</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a onclick="location.href = '/admin/users';"  class="nav-link ">
                <span class="menu-title">Пользователи</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/promo';" >
                <span class="menu-title">Промокоды</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
             <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/deps';" >
                <span class="menu-title">Пополнения</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/withdraws';" >
                <span class="menu-title">Выплаты</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/stat';" >
                <span class="menu-title">Статистика сайта</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
              <li class="nav-item active">
              <a class="nav-link" onclick="location.href = '/admin/percent';" >
                <span class="menu-title">Шансы</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
            
              </span>
            </li>
          </ul>
        </nav>
      
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
<div class="row" id="refs" >
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Шансы 
                    <button id='saved' class="btn btn-gradient-primary" style="" data-toggle="modal" data-target="#addper" >Добавить</button><br><br>
                     
                  </h4>
                     <center>

<table id="per-tbl" class="table-responsive-sm table table-striped- table-bordered table-hover table-checkable" style="width:100%">
                    
				<thead>
					<tr>
						<th class="tbl-name">ID</th>
                        <th class="tbl-name">Процент</th>
                        <th class="tbl-name">Шанс выпадения</th>
                        <th class="tbl-name">Выпадает</th>
                        <th class="tbl-name">Статус</th>
                        <th class="tbl-name">Действие</th>
						
						
					</tr>
				</thead>
                      <tbody>
                      <?php 
while($row = mysql_fetch_array($result5)) {
$id = $row['id'];
$per = $row['per'];
$chance = $row['chance'];
$is_drop = $row['is_drop'];
$is_active = $row['active'];
  if($is_active == 1) {
$status_active = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-success' style='width:100px'>Активно</span></td>";
  }
  if($is_active == 0) {
 $status_active = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-danger' style='width:100px'>Неактивно</span></td>";   
  }
  if($is_drop == 1) {
$status = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-success' style='width:100px'>Да</span></td>";
  }
  if($is_drop == 0) {
 $status = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-danger' style='width:100px'>Нет</span></td>";   
  }
$edit = "<td class='sorting_1' tabindex='0' style='color:green' onclick="." select('$id')"."  data-toggle='modal' data-target='#editper'><span class='badge badge-warning'  style='width:100px'>Изменить</span></td>";

echo "<tr role='row' class='odd'>
<td class='sorting_1' tabindex='0'>$id</td>
<td class='sorting_1' tabindex='0'>$per%</td>
<td class='sorting_1' tabindex='0'>$chance%</td>
$status
$status_active
$edit
</tr>";
}
  ?>

                      </tbody>
			</table>
                      </center>
                      
                      <div class="modal fade show infotbl" id="addper" tabindex="-1" style="display: none;">
    <div class="modal-dialog modal-dialog-md modal-dialog-centered">
        <div class="modal-content"><a class="modal-close" id="close-mod-add" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
            <div class="popup-body">
    <center><p>Добавление процента</p>
    <hr>
    
    <div class="input-item input-with-label input-bordered col-12" style='border:none; '><br>
    <p>Выпадает?
    <select class="input-bordered col-12" style='' id="per_drop">
      <option value="1">Да</option>
      <option value="0">Нет</option>
     
     </select></p><br>
      <p>Процент
<input type="text" class="input-bordered col-12" style='' id="percent" value="" placeholder="Введите процент"></p><br>
    <p>Шанс выпадения
<input type="text" class="input-bordered col-12" style='' id="chance" value="" placeholder="Введите шанс выпадения"></p><br>
     
    <span id="succes_creatper" style="color:gray;"></span>
    <span id="error_creatper" style="color:gray;"></span>
    <!-- КОНЕЦ -->
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style='width:260px' onclick="addper()">Добавить процент</button> 
      </div>
</center>

            </div>
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div>
      <!-- END MODAL -->
    
    <!-- MODAL -->
    <div class="modal fade show infotbl" id="editper" tabindex="-1" style="display: none;">
    <div class="modal-dialog modal-dialog-md modal-dialog-centered">
        <div class="modal-content"><a id="close-mod-add-edit" class="modal-close" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
            <div class="popup-body">
    <center><p>Изменение настроек процента <span id='editperid' style='display:none'></span></p>
    <hr>
    
    <div class="input-item input-with-label input-bordered col-12" style='border:none; '><br>
    <p>Статус
    <select class="input-bordered col-12" style='' id="new_status">
      <option value="1">Активно</option>
      <option value="0">Неактивно</option>
     
     </select></p><br>
    <p>Выпадает?
    <select class="input-bordered col-12" style='' id="newper_drop">
      <option value="1">Да</option>
      <option value="0">Нет</option>
     
     </select></p><br>
      <p>Процент
<input type="text" class="input-bordered col-12" style='' id="newpercent" value="" placeholder="Введите процент"></p><br>
    <p>Шанс выпадения
<input type="text" class="input-bordered col-12" style='' id="newchance" value="" placeholder="Введите шанс выпадения"></p><br>
     
    <span id="succes_saveeditper" style="color:gray;"></span>
    <span id="error_saveeditper" style="color:gray;"></span>
    <!-- КОНЕЦ -->
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style='' onclick="saveper()">Сохранить</button> 
    
      </div>
</center>
 </div>
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div>
      <!-- END MODAL -->
                       
                        </div></div></div>
                        
              </div>

   
  
               



          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="https://vk.com/gscript_s" target="_blank">GScript</a>. Все права защищены.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Сделано с  <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
 
  </body>
</html>
<script>
    function saveper() {
    $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
		$("#error_saveeditper").hide();     	 
										},	
                                                                                data: {
                                                                                    type: "saveeditper",
           																	id: $('#editperid').html(),
                                                                            newstatus: $('#new_status').val(),
                                                                            newdrop: $('#newper_drop').val(),
                                                                            newchance: $('#newchance').val(),
                                                                            newper: $('#newpercent').val()
                                 
           
                                                                                  },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                   
                $("#close-mod-add-edit").click();
                $("#per-tbl").load("percent.php #per-tbl");
                                            
                                                              
                                            }else{
               $("#error_saveeditper").show();     
               $("#error_saveeditper").html(obj.error);     
               $("#per-tbl").load("percent.php #per-tbl");
                                            }
                                        }   
   });
  }
    function select(id) {
   
    $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			 
										},	
                                                                                data: {
                                                                                    type: "selectper",
           id: id
                                 
           
                                                                                  },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                $('#editperid').html(obj.id);                              
                $("#newpercent").val(obj.per);
                $("#newchance").val(obj.chance);
                //$("#newper_drop").val(obj.drop);
               // $("#new_status").val(obj.status);   
                //$("#close-mod-add").click();
                $("#per-tbl").load("percent.php #per-tbl");
                                            
                                                              
                                            }else{
               $("#error_creatper").html(obj.error);     
               $("#per-tbl").load("percent.php #per-tbl");
                                            }
                                        }   
   });
  }
    function addper() {
    $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			 
										},	
                                                                                data: {
                                                                                    type: "addper",
           percent: $("#percent").val(),
           chance: $("#chance").val(),
           drop: $("#per_drop").val()                           
           
                                                                                  },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                $("#close-mod-add").click();
                $("#per-tbl").load("percent.php #per-tbl");
                                            
                                                              
                                            }else{
               $("#error_creatper").html(obj.error);     
               $("#per-tbl").load("percent.php #per-tbl");
                                            }
                                        }   
   });
  }
   function withdraw_adm(status) {
   $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			 
										},	
                                                                                data: {
                                                                                    type: "editstatus",
           id_edit: $("#editid").html(),
           status: status                                                                     },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                $("#close-mod").click();
                $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            
                                                              
                                            }else{
               $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            }
                                        }   
   });
  }
  </script>
<?php } else { header('Location: ../error404'); } ?>