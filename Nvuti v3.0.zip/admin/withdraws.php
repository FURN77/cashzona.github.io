<?php
require("../inc/bd.php"); 
require("../inc/site_config.php"); 
session_start();
$sid = $_SESSION['hash'];

// проверка на админа
$admin_check = "SELECT * FROM kot_user WHERE hash = '$sid'";
$result_admin = mysql_query($admin_check);
$row = mysql_fetch_array($result_admin);
if($row)
{	
    $img = $row['img'];
    $vk_name = $row['vk_name'];
    
$last_check = $row['admin'];
}
if($last_check==1){
$status='Администратор';
}
if($last_check==0){
$status='Игрок';
}
if($last_check==2){
$status='Модератор';
}
$sql_select5 = "SELECT * FROM kot_withdraws ORDER BY id + 0 DESC";
$result5 = mysql_query($sql_select5);
if($last_check == 1) {
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    
    <link rel="stylesheet" href="../css/5style.css">
   
    <!-- Темная тема 
     <link rel="stylesheet" href=" https://www.bootstrapdash.com/demo/purple/jquery/template/assets/css/demo_2/style.css">
     ------>
     <!-- CВетлая тема -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <!--  -------------->
    
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
          <a class="navbar-brand brand-logo-mini" href="/"><font style="color:#d386ff";><b><?=$sitename;?></b></font></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
           <script>
           
           
             function offliner() {

  $('#mybalance').load('/inc/main.php #mybalance');
		}
		
		setInterval('offliner()',3000);   
                             
                              </script>
          
         
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="<?=$img;?>" alt="image">
                  <span class="availability-status online"></span>
                </div>
                
              </a>
             
            </li>
            
            
            <li class="nav-item dropdown">
             <div>
                 <span id="mybalance"><?=$balance;?></span><i class="mdi mdi-coin"></i>
               
              </div>
            </li>
          
       
          
          
            
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="nav-profile-image">
                  <img src="<?=$img;?>" alt="profile">
                  <span class="login-status online"></span>
                  <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?=$vk_name;?></span>
                  <span class="text-secondary text-small"><?=$status;?></span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/';" >
                <span class="menu-title">Главная страница сайта</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
          
            <li class="nav-item ">
                
              <a class="nav-link "  href = "/admin/index.php">
                <span class="menu-title">Настройки</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a onclick="location.href = '/admin/users';"  class="nav-link ">
                <span class="menu-title">Пользователи</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/promo';" >
                <span class="menu-title">Промокоды</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
             <li class="nav-item ">
              <a class="nav-link" onclick="location.href = '/admin/deps';" >
                <span class="menu-title">Пополнения</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" onclick="location.href = '/admin/withdraws';" >
                <span class="menu-title">Выплаты</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/stat';" >
                <span class="menu-title">Статистика сайта</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
              <li class="nav-item">
              <a class="nav-link" onclick="location.href = '/admin/percent';" >
                <span class="menu-title">Шансы</span>
                <i class="mdi mdi-coins menu-icon"></i>
              </a>
            </li>
            
            
              </span>
            </li>
          </ul>
        </nav>
      
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
<div class="row" id="refs" >
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Выплаты 
                    <button class="btn btn-gradient-primary" style="" data-toggle="modal" data-target="#addfake" >Фейк выплата</button>
            
                  </h4>
                   
                       
                        <center>

<table id="withdraws-tbl" class="table-responsive-sm table table-striped- table-bordered table-hover table-checkable">
                    
				<thead>
					<tr>
						<th class="tbl-name">ID</th>
                        <th class="tbl-name">Фейк</th>
                        <th class="tbl-name">Дата</th>
                        <th class="tbl-name">ID игрока</th>
                        <th class="tbl-name">Логин</th>
						<th class="tbl-name">ПС</th>
						<th class="tbl-name">Кошелек</th>
						<th class="tbl-name">Сумма</th>
						<th class="tbl-name">Статус</th>
						
					</tr>
				</thead>
                      <tbody>
                      <?php 
while($row = mysql_fetch_array($result5)) {
$id = $row['id'];
$user_id = $row['user_id'];
$sum = $row['sum'];
$wallet = $row['wallet'];
$status = $row['status'];
$ps = $row['ps'];
$fake = $row['fake'];
$date = $row['date'];
if($fake == 0) {
$is_fake = "Нет";
$sql_select2 = "SELECT * FROM kot_user WHERE id='$user_id'";
$result2 = mysql_query($sql_select2);
$row = mysql_fetch_array($result2);
if($row)
{
$login = $row['login'];
}
}
if($fake == 1) {
  $user_id = "Нет";
  $is_fake = "Да";
  $login = $row['login_fake'];
}
if($status == 0) {
  $stat = "<td class='sorting_1' tabindex='0' onclick="."$('#editid').html('$id');"."  data-toggle='modal' data-target='#editstatus'><span class='badge badge-warning'>Изменить</span></td>";
}
if($status == 1) {
  $stat = "<td class='sorting_1' tabindex='0' style='color:green'><span class='badge badge-success'>Выполнено</span></td>";
}
if($status == 2) {
  $stat = "<td class='sorting_1' tabindex='0' style='color:red'><span class='badge badge-danger'>Отклонено</span></td>";
}
echo "<tr role='row' id='$id' class='odd'>
<td class='sorting_1' tabindex='0'>$id</td>
<td class='sorting_1' tabindex='0'>$is_fake</td>
<td class='sorting_1' tabindex='0'>$date</td>
<td class='sorting_1' tabindex='0'>$user_id</td>
<td class='sorting_1' tabindex='0'>$login</td>
<td class='sorting_1' tabindex='0'><img src='../images/$ps.png'></td>
<td class='sorting_1' tabindex='0'>$wallet</td>
<td class='sorting_1' tabindex='0'>$sum</td>
$stat
</tr>";
}
  ?>

                      </tbody>
			</table>
                      </center>
              
                       <!-- КОНЕЦ -->
                       <div class="modal fade show infotbl" id="addfake" tabindex="-1" style="display: none;">
    <div class="modal-dialog modal-dialog-md modal-dialog-centered">
        <div class="modal-content"><a class="modal-close" id="close-mod-add" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
            <div class="popup-body">
    <center><p>Добавление фейк выплаты</p>
    <hr>
    
    <div class="input-item input-with-label input-bordered col-12" style='border:none; '><br>
    <p>Выберите систему
    <select class="input-bordered col-12" style='' id="ps_fake">
      <option value="0">Qiwi</option>
      <option value="1">Payeer</option>
      <option value="2">Яндекс.Деньги</option>
      <option value="3">WebMoney</option>
      <option value="4">Билайн</option>
      <option value="5">Мегафон</option>
      <option value="6">МТС</option>
      <option value="7">Теле 2</option>
      <option value="8">VISA</option>
      <option value="9">MASTERCARD</option>
     
     </select></p><br>
      <p>Логин игрока (любой)
<input type="text" class="input-bordered col-12" style='' id="loginfake" value="" placeholder="Введите логин"></p><br>
    <p>Сумма вывода
<input type="text" class="input-bordered col-12" style='' id="sumfake" value="" placeholder="Введите сумму"></p><br>
      <p>Кошелек
<input type="text" class="input-bordered col-12" style='' id="walletfake" value="" placeholder="Введите кошелек"></p><br>
    <!-- ОПОВЕЩЕНИЯ -->
    <span id="succes_creatfake" style="color:gray;"></span>
    <span id="error_creatfake" style="color:gray;"></span>
    <!-- КОНЕЦ -->
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style='width:260px' onclick="addwithdrawfake()">Добавить выплату</button> 
      </div>
</center>

            </div>
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div>
      <!-- END MODAL -->
    
    <!-- MODAL -->
    <div class="modal fade show infotbl" id="editstatus" tabindex="-1" style="display: none;">
    <div class="modal-dialog modal-dialog-md modal-dialog-centered">
        <div class="modal-content"><a id="close-mod" class="modal-close" data-dismiss="modal" aria-label="Close"><em class="ti ti-close"></em></a>
            <div class="popup-body">
    <center><p>Изменение статуса выплаты <span id='editid' style='display:none'></span></p>
    <hr>
    
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style='width:140px; display:inline-block' onclick="withdraw_adm('succes')">Выплачено <i class='fa fa-check' style='color:green'></i></button>  
    
    <button class="btn btn-sm btn-outline btn-light input-bordered col-12" style='width:140px; display:inline-block' onclick="withdraw_adm('error')">Отклонено <i class='fa fa-times' style='color:red'></i></button>
</center>

            </div>
        </div><!-- .modal-content -->
    </div><!-- .modal-dialog -->
</div>
      <!-- END MODAL -->
                        </div></div></div>
                        
              </div>

   
  
               



          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="https://vk.com/gscript_s" target="_blank">GScript</a>. Все права защищены.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Сделано с  <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
  
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
 
  </body>
</html>
<script>
    function addwithdrawfake() {
    $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			 
										},	
                                                                                data: {
                                                                                    type: "addfakewithdraw",
           fwallet: $("#walletfake").val(),
           flogin: $("#loginfake").val(),
           fsum: $("#sumfake").val(),                           
           fsystem: $("#ps_fake").val()
                                                                                  },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                $("#close-mod-add").click();
                $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            
                                                              
                                            }else{
               $("#error_creatfake").html(obj.error);     
               $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            }
                                        }   
   });
  }
   function withdraw_adm(status) {
   $.ajax({
                                                                                type: 'POST',
                                                                                url: '/admin/admin_func.php',
beforeSend: function() {
			 
										},	
                                                                                data: {
                                                                                    type: "editstatus",
           id_edit: $("#editid").html(),
           status: status                                                                     },
                                        success: function(data) {
                                            var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                $("#close-mod").click();
                $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            
                                                              
                                            }else{
               $("#withdraws-tbl").load("withdraws.php #withdraws-tbl");
                                            }
                                        }   
   });
  }
  </script>
<?php } else { header('Location: ../error404'); } ?>